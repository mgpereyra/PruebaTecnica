﻿using GestionPersonal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionPersonal.Repositories
{
    public interface IEmpleadoRepository
    {
        Task<List<Empleado>> GetEmpleados();
        Task<Empleado> GetEmpleadoById(int id);
        void AddEmpleado(Empleado empleado);
        void UpdateEmpleado(Empleado empleado);
        Task SaveChangesAsync();
    }
}
