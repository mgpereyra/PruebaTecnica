﻿using GestionPersonal.DataAccess;
using GestionPersonal.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionPersonal.Repositories
{
    public class EmpleadoRepository : IEmpleadoRepository
    {
        private readonly EmpleadoContext _context;

        public EmpleadoRepository(EmpleadoContext context)
        {
            _context = context;
        }

        public async Task<List<Empleado>> GetEmpleados()
        {
            return await _context.Empleados.ToListAsync();
        }

        public async Task<Empleado> GetEmpleadoById(int id)
        {
            return await _context.Empleados.FindAsync(id);
        }


        public void AddEmpleado(Empleado empleado)
        {
            _context.Empleados.Add(empleado);
            _context.SaveChanges();
        }

        public void UpdateEmpleado(Empleado empleado)
        {
            _context.Entry(empleado).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
