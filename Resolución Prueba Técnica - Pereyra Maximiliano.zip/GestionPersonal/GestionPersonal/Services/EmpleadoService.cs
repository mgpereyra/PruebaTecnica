﻿using GestionPersonal.Models;
using GestionPersonal.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionPersonal.Services
{
    public class EmpleadoService : IEmpleadoService
    {
        private readonly IEmpleadoRepository _empleadoRepository;
        public EmpleadoService(IEmpleadoRepository empleadoRepository)
        {
            _empleadoRepository = empleadoRepository;
        }
        public async Task<List<Empleado>> GetEmpleados()
        {
            return await _empleadoRepository.GetEmpleados();
        }

        public async Task<Empleado> GetEmpleadoById(int id)
        {
            return await _empleadoRepository.GetEmpleadoById(id);
        }

        public async Task<int> AddEmpleado(Empleado empleado)
        {
            _empleadoRepository.AddEmpleado(empleado);
            await _empleadoRepository.SaveChangesAsync();
            return empleado.ID;
        }

        public async Task UpdateEmpleado(Empleado empleado)
        {
            _empleadoRepository.UpdateEmpleado(empleado);
            await _empleadoRepository.SaveChangesAsync();
        }
    }
}
