﻿using GestionPersonal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionPersonal.Services
{
    public interface IEmpleadoService
    {
        Task<List<Empleado>> GetEmpleados();
        Task<Empleado> GetEmpleadoById(int id);
        Task<int> AddEmpleado(Empleado empleado);
        Task UpdateEmpleado(Empleado empleado);
        // Task SaveChangesAsync();

    }
}
