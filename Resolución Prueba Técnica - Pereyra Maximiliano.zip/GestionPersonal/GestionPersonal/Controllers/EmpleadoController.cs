﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GestionPersonal.DataAccess;
using GestionPersonal.Models;
using GestionPersonal.Repositories;
using GestionPersonal.Services;

namespace GestionPersonal.Controllers
{
    public class EmpleadoController : Controller
    {
        private readonly EmpleadoContext _context;
        // private readonly IEmpleadoRepository _empleadoRepository;
        private readonly IEmpleadoService _empleadoService;

        public EmpleadoController(EmpleadoContext context, IEmpleadoService empleadoService) //, IEmpleadoRepository empleadoRepository)
        {
            //_empleadoRepository = empleadoRepository;
            _empleadoService = empleadoService;
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // var empleados = await _empleadoRepository.GetEmpleados();
            var empleados = await _empleadoService.GetEmpleados();
            return View(empleados);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // var empleado = await _context.Empleados.FirstOrDefaultAsync(m => m.ID == id);
            var empleado = await _empleadoService.GetEmpleadoById(id.Value);
            if (empleado == null)
            {
                return NotFound();
            }

            return View(empleado);
        }

        public IActionResult Create()
        {
            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("ID, Apellido, Nombre, Dni, CorreoElectronico, Celular")] Empleado empleado)
        {
            if (ModelState.IsValid)
            {
                _empleadoService.AddEmpleado(empleado);
                //_empleadoRepository.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(empleado);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var empleado = await _empleadoService.GetEmpleadoById(id.Value);
            if (empleado == null)
            {
                return NotFound();
            }
            return View(empleado);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Apellido,Nombre,Dni,CorreoElectronico,Celular")] Empleado empleado)
        {
            if (id != empleado.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // _context.Update(empleado);
                    // await _context.SaveChangesAsync();
                    await _empleadoService.UpdateEmpleado(empleado);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmpleadoExists(empleado.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(empleado);
        }

        private bool EmpleadoExists(int id)
        {
            return _context.Empleados.Any(e => e.ID == id);
        }
    }
}
