create database prueba;

use prueba;

create table Empleados
(
	ID INT PRIMARY KEY IDENTITY (1, 1),
    Apellido VARCHAR (50) NOT NULL,
    Nombre VARCHAR (50) NOT NULL,
    Dni VARCHAR (10) NOT NULL,
    CorreoElectronico VARCHAR(80),
    Celular VARCHAR (20) NOT NULL,);

select * from Empleados;

insert into Empleados
values('Pereyra','Maximiliano','12345678', 'pereyra.m@outlook.com','1164559922');

-- drop table empleados;